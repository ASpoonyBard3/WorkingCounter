﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACounterUsingDelegates
{
    public class Item
    {
        public string Name { get; set; }
        public Colour Colours { get; set; }

        public Item(string name, Colour colour) 
        {
            Name = name;
            Colours = colour;
        }

    }
}
