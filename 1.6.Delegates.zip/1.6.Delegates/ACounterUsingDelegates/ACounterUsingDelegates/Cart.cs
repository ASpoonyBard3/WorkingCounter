﻿using GenericsACounterUsingDelegatesCounter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACounterUsingDelegates
{
    public class Cart : Counter<Box>
    {
        //doesn't need any code as it inherits all methods from the generic counter class
    }
}
