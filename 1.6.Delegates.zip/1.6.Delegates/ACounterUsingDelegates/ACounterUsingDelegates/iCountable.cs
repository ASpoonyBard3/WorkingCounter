﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACounterUsingDelegates
{
    public interface iCountable
    {
        public int Count { get; }
    }
}
