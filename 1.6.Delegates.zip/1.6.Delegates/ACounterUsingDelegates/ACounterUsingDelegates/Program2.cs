﻿using ACounterUsingDelegates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsCounter
{
    class Program
    {

        static void Main(string[] args)
        {

            

            //declare new box
            Box box = new Box();
            //add apples to box 
            box.Add(new Apple());
            box.Add(new Apple());
            box.Add(new Apple());
            box.Add(new Apple());
            box.Add(new Apple());


            //creates a second box
            Box box2 = new Box();

            //adds an apple to it
            box2.Add(new Apple());
            box2.Add(new Apple());
            box2.Add(new Apple());

            //creates a cart, adds box to the cart
            Cart cart = new Cart();
            cart.Add(new Box());
            cart.Add(box);
            cart.Add(box2);

            //create an object of the delegate and assign a method to filter out only red apples
            ObjectCanBeCounted CountRedApples;
            CountRedApples.Invoke(box, colour);

            //print to console, number of apples in box
            Console.WriteLine("There are " + box.Count + " apples in the first box");
            Console.ReadLine();

            //print contents of cart to console
            Console.WriteLine("There are " + cart.Count + " boxes in the cart.");
            Console.ReadLine();

        }

        delegate void ObjectCanBeCounted(Item Colour);
        /*{
            // this delegates checks if an object derives from item, 
            //and if it does then checks if it implements the iCountable interface
            //if both statements evaluated to true, then the item can be counted,
            //if not then the item should not be counted.
            

            /*if(typeof().IsSubclassOf(typeof(Item))
            
            if (Item is iCountable)
            {
                return 
            };
            else
            */
            //this should work but doesn't because of older version of c#...

    }

}