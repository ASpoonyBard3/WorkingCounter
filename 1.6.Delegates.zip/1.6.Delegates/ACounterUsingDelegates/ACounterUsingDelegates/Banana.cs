﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACounterUsingDelegates
{
    class Banana : Item, iCountable 
    {
        //implements icountable as it counts a single object, banana
        public int Count => 1;
    }
}
