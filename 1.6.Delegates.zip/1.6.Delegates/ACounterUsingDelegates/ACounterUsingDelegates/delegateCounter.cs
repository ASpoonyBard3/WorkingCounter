﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACounterUsingDelegates
{
    class delegateCounter
    {
        public delegate void countableObjects(Item item);
        {
            if (Item is iCountable); //this should work but doesn't because of older version of c#...
            
            if( typeof(iCountable).IsAssignableFrom(Item item));

        }
    }
}
