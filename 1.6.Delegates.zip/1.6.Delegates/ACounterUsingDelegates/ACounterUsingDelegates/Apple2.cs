﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ACounterUsingDelegates;

namespace ACounterUsingDelegates
{
    public class Apple : Item, iCountable // we can inherit from a base class and an interface as long as we inherit first then implement interface.
    {
        public string ColourRed = "red";
        public string ColourGreen = "green";

        //this doesn't work in C# 4.0 which is the work install but does work on c#5.0, not sure why, the explanations seemed irrelevant.
        int Count => 1;
    }
}
